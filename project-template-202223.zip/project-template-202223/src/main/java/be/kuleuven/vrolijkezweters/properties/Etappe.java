package be.kuleuven.vrolijkezweters.properties;

public class Etappe {
    private int etappeID, wedstrijdId, afstand;

    public Etappe(int etappeID, int wedstrijdId, int afstand) {
        this.etappeID = etappeID;
        this.wedstrijdId = wedstrijdId;
        this.afstand = afstand;
    }

}
