package be.kuleuven.vrolijkezweters.properties;

public class Wedstrijd {
    private int wedstrijdId, afstand, inschrijvingsGeld, beginUur;
    private String plaats, datum;

    public Wedstrijd(int wedstrijdId, String plaats, int afstand, int inschrijvingsGeld, String datum, int beginUur) {
        this.wedstrijdId = wedstrijdId;
        this.plaats = plaats;
        this.afstand = afstand;
        this.inschrijvingsGeld = inschrijvingsGeld;
        this.datum = datum;
        this.beginUur = beginUur;
    }
}
