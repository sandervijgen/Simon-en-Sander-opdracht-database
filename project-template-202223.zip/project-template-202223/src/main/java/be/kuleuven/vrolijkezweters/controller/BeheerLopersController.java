package be.kuleuven.vrolijkezweters.controller;

public class BeheerLopersController {

    public void initialize() {

    }
}
